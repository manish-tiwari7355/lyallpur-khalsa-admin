import { connect } from 'umi';
import Breadcrumbs from '@/components/BreadCrumbs';
import React, { useEffect, useState } from 'react';
import Page from '@/components/Page';

import OrderTable from './OrderTable';
import { Tabs } from 'antd';

function Orders({ dispatch, loading, currentUser, OrderList }) {
  const [currentPage, setCurrentPage] = useState(1);
  const [startIndex, setStartIndex] = useState(0);
  const [viewSize, setViewSize] = useState(10);
  const [searchText, setSearchText] = useState('');
  const { TabPane } = Tabs;
  const [tab, setTab] = useState('ALL Orders');

  console.log(OrderList?.orderData, 'orderlist');

  const getCategoryList = () => {
    dispatch({
      type: 'order/orderList',
      payload: {
        query: {
          viewSize,
          startIndex,
          keyword: searchText,
          page: currentPage,
        },
      },
    });
  };

  useEffect(() => {
    // eslint-disable-next-line no-underscore-dangle
    if (currentUser?._id) getCategoryList();
  }, [currentUser, searchText, currentPage]);

  return (
    <div className="container mx-auto">
      <Page
        title="Orders"
        breadcrumbs={
          <Breadcrumbs
            path={[
              {
                name: 'Dashboard',
                path: '/dashboard',
              },
              {
                name: 'Orders',
                path: '/orders',
              },
            ]}
          />
        }
      >
        <div className="bg-white rounded shadow mb-3 p-3">
          <Tabs
            activeKey={tab}
            onTabClick={(val) => {
              setTab(val);
              setSearchText('');
              setViewSize(10);
              setStartIndex(0);
              setCurrentPage(1);
            }}
          >
            <TabPane tab={<span className="px-4">All Orders</span>} key="ALL_Orders">
              <OrderTable
                tableData={OrderList?.orderData}
                currentPage={currentPage}
                startIndex={startIndex}
                viewSize={viewSize}
                setCurrentPage={setCurrentPage}
                setStartIndex={setStartIndex}
                setViewSize={setViewSize}
                setSearchText={setSearchText}
                searchText={searchText}
                loading={loading}
              />
            </TabPane>
          </Tabs>
        </div>
      </Page>
    </div>
  );
}
const mapStateToProps = ({ user, order, loading }) => ({
  currentUser: user?.currentUser,
  OrderList: order?.ordersList,
  loading: loading.effects['order/orderList'],
});
export default connect(mapStateToProps)(Orders);
